wx.cloud.init()
export const db = wx.cloud.database()

export const cloud = wx.cloud